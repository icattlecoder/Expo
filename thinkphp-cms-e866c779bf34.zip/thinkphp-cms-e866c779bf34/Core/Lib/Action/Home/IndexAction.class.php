<?php
/**
 * 前台入口模块
 * 
 */
class IndexAction extends HomeAction {
    public function index(){
		$this->display();
	}
	
}