<?php
return array (
  'default_theme' => 'default',
);
?>