<?php
/**
 * CMS后台 登录模块简体中文语言包
 * @author   Wang Jiaqi
 */
return array(
		'lan_username'        =>'用户名',
		'lan_password'        =>'密码',
		'lan_verify'          =>'验证码',
		'lan_input_user_name' =>'请输入用户名',
		'lan_input_password'  =>'请输入密码',
		'lan_input_verify'    =>'请输入验证码',
);