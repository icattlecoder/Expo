<?php
/**
 * CMS后台 登录模块英文语言包
 * @author   Wang Jiaqi
 */
return array(
	'lan_username'        =>'Username',
	'lan_password'        =>'Password',
	'lan_verify'          =>'Verify',
	'lan_input_user_name' =>'Please input user name',
	'lan_input_password'  =>'Please input password',
	'lan_input_verify'    =>'Please input verify',
);