<?php
return array (
  'db_type' => 'mysql',
  'db_host' => '127.0.0.1',
  'db_name' => 'cms',
  'db_user' => 'root',
  'db_pwd' => '',
  'db_port' => 3306,
  'db_prefix' => 'tp_',
  'web_name' => 'CMS网',
  'web_url' => 'http://cms.demo.com/',
  'web_path' => '/',
  'web_icp' => '粤ICP备000000号',
  'CRON_MAX_TIME' => 60,
  'web_copyright' => '',
  'web_tongji' => '',
  'web_admin_pagenum' => 20,
  'web_home_pagenum' => 15,
  'web_adsensepath' => 'Public/Banner',
);
?>